var searchData=
[
  ['student_2ec',['student.c',['../student_8c.html',1,'']]],
  ['student_2eh',['student.h',['../student_8h.html',1,'']]]
];
