/**
@file course.h

@author Jackson Cassidy

@date 2022/04/12

@brief Header file for the Course type and related functions
*/

#include "student.h"
#include <stdbool.h>

/**
Course type stores a course with fields name, code, students, and total_students
*/
typedef struct _course 
{
  char name[100]; /**< the courses name */
  char code[10]; /**< the course code */
  Student *students; /**< the list of students in the course */
  int total_students; /**< the course's number of total students */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


