/**
@file student.h

@author Jackson Cassidy

@date 2022/04/12

@brief Header file for the Student type and related functions
*/


/**
Student type stores a student with fields first_name, last_name, id, grades, num_grades

*/
typedef struct _student 
{ 
  char first_name[50]; /**< the students first name */
  char last_name[50]; /**< the students last name */
  char id[11]; /**< the students id number */
  double *grades; /**< a list of the students grades */
  int num_grades; /**< the number of grades the student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
